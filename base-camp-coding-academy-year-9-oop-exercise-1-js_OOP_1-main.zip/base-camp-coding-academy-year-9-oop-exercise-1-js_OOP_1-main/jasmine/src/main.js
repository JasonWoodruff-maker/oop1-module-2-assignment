class Person {
    constructor(fname, lname, age, state, country){
        this.fname = fname;
        this.lname = lname;
        this.age = age;
        this.state = state;
        this.country = country;
    }
};

const people = [
    new Person('John', 'Doe', 30, 'New York', 'USA'),
    new Person('Alice', 'Smith', 25, 'California', 'USA'),
    new Person('Bob', 'Johnson', 35, 'Texas', 'USA'),
    new Person('Eva', 'Brown', 28, 'New York', 'USA'),
];

function printInfo(people){
    for (let x in people){
        console.log("Details of All People:")
        console.log("First Name: " + people[x].fname);
        console.log("Last Name: " + people[x].lname);
        console.log("Age: " + people[x].age);
        console.log("State: " + people[x].state);
        console.log("Country: " + people[x].country);
        console.log("----------")
    }
};
function filterState(state){
   console.log(`People from ${state}:`)
   for (let x in people){
        if (people[x].state == state) {
            console.log("First Name: " + people[x].fname);
            console.log("Last Name: " + people[x].lname);
            console.log("Age: " + people[x].age);
            console.log("State: " + people[x].state);
            console.log("Country: " + people[x].country);
            console.log("----------")
        }
    }
}